#! /bin/bash
sudo yum -y remove falcon-sensor
